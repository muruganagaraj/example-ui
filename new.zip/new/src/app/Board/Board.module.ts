// Library Modules
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { BoardRouting } from './Board.routing';
import { DashBoardComponent } from '../Board/DashBoard/DashBoard.component';

@NgModule({
    imports: [
        CommonModule, RouterModule, FormsModule, BoardRouting
    ],
    declarations: [DashBoardComponent],
    exports: [
        RouterModule
    ],
    providers: [],
    entryComponents: []
})

export class BoardModule {
}