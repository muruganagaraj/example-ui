import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'attoney-first-dashboard',
    templateUrl: 'DashBoard.component.html'
})
export class DashBoardComponent implements OnInit {
    constructor() {

    }
    ngOnInit(): void {
        alert('DashBoard Component');
    }
}
