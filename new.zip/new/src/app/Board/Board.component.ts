import { Component } from '@angular/core';
import { takeUntil } from 'rxjs/operators';
import { ActivatedRoute } from '@angular/router';
import { Constants } from '../../shared/constants/constants';

@Component({
    selector: 'attoney-first-board',
    templateUrl: 'Board.component.html'
})
export class BoardComponent {
    constructor() {

    }
}
