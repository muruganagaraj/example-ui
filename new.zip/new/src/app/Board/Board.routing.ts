import { Routes, RouterModule } from '@angular/router';
import { ModuleWithProviders } from '@angular/core';
import { DashBoardComponent } from './DashBoard/DashBoard.component';
import { CanActivateRouteGuard } from '../../shared/providers/route-guards/can-activate-route-guard.provider';
import { RouteConstants } from '../../shared/constants/route.constants';
const appRoutes: Routes = [
    {
        path: RouteConstants.dashboard, component: DashBoardComponent,
        canActivate: [CanActivateRouteGuard], runGuardsAndResolvers: 'always'
    }
];

export const BoardRouting: any = RouterModule.forChild(appRoutes);
