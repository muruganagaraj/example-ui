import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CanActivateRouteGuard } from '../shared/providers/route-guards/can-activate-route-guard.provider';
import { LoginComponent } from '../app/Home/Login/Login.component';
import { RouteConstants } from '../shared/constants/route.constants';

const routes: Routes = [
    { path: RouteConstants.login, component: LoginComponent },
    { path: '**', redirectTo: RouteConstants.login }
];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})
export class AppRoutingModule { }
