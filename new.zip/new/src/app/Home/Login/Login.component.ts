import { Component } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { RouteConstants } from '../../../shared/constants/route.constants';

@Component({
    selector: 'attorney-first-login',
    templateUrl: './Login.component.html',
    styleUrls: ['./Login.component.scss']
})
export class LoginComponent {
    constructor(private router: Router) {

    }
    onDashboardClick(): void {
        this.router.navigate([RouteConstants.dashboard]);
    }
    onFileClick(): void {
        this.router.navigate([RouteConstants.createfile]);
    }
}
