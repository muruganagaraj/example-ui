// Library Modules
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { FileRouting } from './File.routing';
import { CreateFileComponent } from '../File/CreateFile/CreateFile.component';

@NgModule({
    imports: [
        CommonModule, RouterModule, FormsModule, FileRouting
    ],
    declarations: [CreateFileComponent],
    exports: [
        RouterModule
    ],
    providers: [],
    entryComponents: []
})

export class FileModule {
}