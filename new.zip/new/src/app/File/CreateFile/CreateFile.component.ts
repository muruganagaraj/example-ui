import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'attoney-first-createfile',
    templateUrl: 'CreateFile.component.html'
})
export class CreateFileComponent implements OnInit {
    constructor() {

    }
    ngOnInit(): void {
        alert('create file component');
    }
}
