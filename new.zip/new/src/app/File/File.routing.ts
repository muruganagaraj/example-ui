import { Routes, RouterModule } from '@angular/router';
import { ModuleWithProviders } from '@angular/core';
import { CreateFileComponent } from './CreateFile/CreateFile.component';
import { CanActivateRouteGuard } from '../../shared/providers/route-guards/can-activate-route-guard.provider';
import { RouteConstants } from '../../shared/constants/route.constants';
const appRoutes: Routes = [
    {
        path: RouteConstants.createfile, component: CreateFileComponent,
        canActivate: [CanActivateRouteGuard], runGuardsAndResolvers: 'always'
    }
];

export const FileRouting: any = RouterModule.forChild(appRoutes);

