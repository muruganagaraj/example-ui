// Routes
export class RouteConstants {
    public static login: string = 'login';
    public static createfile: string = 'createfile';
    public static dashboard: string = 'dashboard';
}